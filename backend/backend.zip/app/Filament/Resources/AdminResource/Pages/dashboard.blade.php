<x-filament::page>
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            @livewire(\App\Filament\Widgets\InfoWidget::class)

    </div>
</x-filament::page>
