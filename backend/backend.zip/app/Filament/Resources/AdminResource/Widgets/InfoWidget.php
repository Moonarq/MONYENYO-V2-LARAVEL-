<?php

namespace App\Filament\Resources\AdminResource\Widgets;

use Filament\Widgets\Widget;

class InfoWidget extends Widget
{
    protected static string $view = 'filament.resources.admin-resource.widgets.info-widget';

    // Optional: Atur columnSpan jika ingin mengatur lebar widget
}
