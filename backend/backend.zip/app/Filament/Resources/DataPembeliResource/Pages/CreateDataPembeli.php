<?php

namespace App\Filament\Resources\DataPembeliResource\Pages;

use App\Filament\Resources\DataPembeliResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataPembeli extends CreateRecord
{
    protected static string $resource = DataPembeliResource::class;
}
